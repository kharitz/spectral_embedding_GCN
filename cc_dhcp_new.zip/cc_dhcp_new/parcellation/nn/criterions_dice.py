import torch
from torch.nn.modules.loss import _Loss
import torch.nn.functional as func


class CompDice(_Loss):
    """
    The Sørensen-Dice Loss.
    """
    def __init__(self):
        super(CompDice, self).__init__()

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor):
        """
        Computes the CrossEntropy and Sørensen–Dice loss.
        Note that PyTorch optimizers minimize a loss. In this case, we would like to maximize the dice loss so we
        return the negated dice loss.
        Args:
            inputs (:obj:`torch.Tensor`) : A tensor of shape (B, C, ..). The model prediction on which the loss has to
             be computed.
            targets (:obj:`torch.Tensor`) : A tensor of shape (B, C, ..). The ground truth.
        Returns:
            :obj:`torch.Tensor`: The Sørensen–Dice loss for each class or reduced according to reduction method.
        """
        if not inputs.size() == targets.size():
            raise ValueError("'Inputs' and 'Targets' must have the same shape.")

        smooth = 1.
        epsilon = 10e-8

        # have to use contiguous since they may from a torch.view op
        iflat = inputs.view(-1).contiguous()
        tflat = targets.view(-1).contiguous()
        intersection = (iflat * tflat).sum()

        A_sum = torch.sum(iflat * iflat)
        B_sum = torch.sum(tflat * tflat)

        dice = (2. * intersection + smooth) / (A_sum + B_sum + smooth)
        dice = dice.mean(dim=0)
        dice = torch.clamp(dice, 0, 1.0)

        return dice