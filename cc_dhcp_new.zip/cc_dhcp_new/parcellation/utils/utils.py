import torch
import torch.nn.functional as func


def compute_dice_metrics(inputs: torch.Tensor, targets: torch.Tensor):
    """
    Computes the dice overlay as accuracy and accuracy
    Args:
        inputs: The output of the model
        targets: The ground truth used to compute the metrics
    Returns:
        Tuple: The dice percentage.
    """

    eps = 0.000000001
    intersection = (func.softmax(inputs, dim=1) * targets).sum(0)
    union = (func.softmax(inputs, dim=1) + targets).sum(0)
    numerator = 2 * intersection
    denominator = union + eps
    dic = 100 * ((numerator / denominator).sum() / 36)
    return dic


def compute_dice_parcels_metrics(inputs: torch.Tensor, targets: torch.Tensor):
    """
    Computes the dice overlay as accuracy and accuracy
    Args:
        inputs: The output of the model
        targets: The ground truth used to compute the metrics
    Returns:
        Tuple: The dice percentage.
    """

    eps = 0.000000001
    intersection = (func.softmax(inputs, dim=1) * targets).sum(0)
    union = (func.softmax(inputs, dim=1) + targets).sum(0)
    numerator = 2 * intersection
    denominator = union + eps
    dic = 100 * (numerator / denominator)
    return dic


def compute_acc_metrics(inputs: torch.Tensor, targets: torch.Tensor):
    """
    Computes the dice overlay as accuracy and accuracy
    Args:
        inputs: The output of the model
        targets: The ground truth used to compute the metrics
    Returns:
        Output: The percentage accuracy.
    """
    pred = torch.max(inputs, 1)[1]
    gt = torch.max(targets, 1)[1]
    acc = 100 * pred.eq(gt).sum().double() / gt.numel()

    return acc


def dice_coeff(pred, target):
    """This definition generalize to real valued pred and target vector.
    This should be differentiable.
    pred: tensor with first dimension as batch
    target: tensor with first dimension as batch
    """

    smooth = 1.
    epsilon = 10e-8

    # have to use contiguous since they may from a torch.view op
    iflat = pred.view(-1).contiguous()
    tflat = target.view(-1).contiguous()
    intersection = (iflat * tflat).sum()

    A_sum = torch.sum(iflat * iflat)
    B_sum = torch.sum(tflat * tflat)

    dice = (2. * intersection + smooth) / (A_sum + B_sum + smooth)
    dice = dice.mean(dim=0)
    dice = torch.clamp(dice, 0, 1.0)

    return  dice
